#include <iostream>
#ifndef FRACTION_H
#define FRACTION_H
using namespace std;


class fraction
{
    public:
        fraction();
        fraction(int num,int dnum);
         friend istream &operator>>(istream &in,fraction &obj);
         friend ostream &operator<<(ostream &out,fraction &obj);
         void simplification();
         fraction operator +(fraction &obj);
         fraction operator -(fraction & obj);
         fraction operator *(fraction &obj);
         fraction operator / (fraction &obj);
         int operator ==(fraction &obj);
         bool operator >(fraction &obj);
         bool operator <(fraction &obj);
         bool operator <=(fraction &obj);
         bool operator >=(fraction &obj);

    private:
        int num,dnum;
};

#endif // FRACTION_H
