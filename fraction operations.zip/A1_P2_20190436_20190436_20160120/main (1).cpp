#include <iostream>
#include "fraction.h"
#include "FractionCalculator.h"
using namespace std;

int main()
{
    FractionCalculator f;
    f.mnue();

    return 0;
}
