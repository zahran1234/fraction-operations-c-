#include "fraction.h"
#include <iostream>
#include <cmath>
using namespace std;
fraction::fraction()
{
    num=0;
    dnum=1;
}
fraction::fraction(int num,int dnum)
{
    this->num=num;
    this->dnum=dnum;
}
void fraction:: simplification()
{
    int mi,ni,ri;
  ni=fabs(dnum);
  mi=fabs(num);
  while(ri=mi%ni)//Find the Maximum Common Number of mi,ni
  {
    mi=ni;
    ni=ri;
  }
  dnum/= ni; // Simplification
  num/=ni;
  if (dnum < 0) // Convert denominator to positive number
  {
    dnum=-dnum;
    num=-num;
  }
}
/*_______________________________________________________________________________________________________________________________*/

/* addition function */

fraction fraction :: operator +(fraction &obj)
{
    this->num=num*obj.dnum+dnum*obj.num;
    this->dnum=dnum*obj.dnum;
    this->simplification();
    return *this;
}
/*_______________________________________________________________________________________________________________________________*/

/*subtraction function */

fraction fraction ::operator -(fraction &obj)
{
    this->num=num*obj.dnum-dnum*obj.num;
    this->dnum=dnum*obj.dnum;
    this->simplification();
    return *this;
}
/*_______________________________________________________________________________________________________________________________*/

/*multiplication function */

fraction fraction ::operator *(fraction &obj)
{
        this->num=num*obj.num;
        this->dnum=dnum*obj.dnum;
        this->simplification();
        return *this;
}
/*_______________________________________________________________________________________________________________________________*/

/* division function */

fraction fraction::operator /(fraction &obj)
{
    this->num=num*obj.dnum;
    this->dnum=dnum*obj.num;
    this->simplification();
    return *this;
}
/*_______________________________________________________________________________________________________________________________*/

/*less than function */

bool fraction::operator <(fraction &obj)
{
    int res1,res2;
    if (obj.dnum==dnum)
    {
        if(res1<res2)
    {
        return 1;
    }
    else {return 0;}
    }
    res1=num*obj.dnum;
    res2=dnum*obj.num;
    if(res1<res2)
    {
        return 1;
    }
    else {return 0;}
}
/*_______________________________________________________________________________________________________________________________*/

/*greater than function */

bool fraction ::operator >(fraction &obj)
{
    int res1,res2;
    res1=num*obj.dnum;
    res2=dnum*obj.num;
    if(res1>res2)
    {
        return 1;
    }
    else {return 0;}
}
/*_______________________________________________________________________________________________________________________________*/

/*less than or equal function */

bool fraction ::operator <=(fraction &obj)
{
    int res1,res2;
    res1=num*obj.dnum;
    res2=dnum*obj.num;
    if (res1==res2)
    {
        return 1;
    }
    if(res1<res2)
    {
        return 1;
    }
    else {return 0;}
}
/*_______________________________________________________________________________________________________________________________*/

/* greater than or equal function */

bool fraction::operator >=(fraction &obj)
{
    int res1,res2;
    res1=num*obj.dnum;
    res2=dnum*obj.num;
    if (res1==res2)
    {
        return 1;
    }
    if(res1>res2)
    {
        return 1;
    }
    else {return 0;}
}
/*_______________________________________________________________________________________________________________________________*/

/*equality function checks if the two fractions is equal to each other or not */

int fraction::operator ==(fraction &obj)
{
    obj.simplification();
    if(num==obj.num&&dnum==obj.dnum)
    {
        return 1;
    }
    else {return 0;}
}
/*_______________________________________________________________________________________________________________________________*/

/*input stream overloading function */

istream &operator>>(istream &in,fraction &obj)
{
    do{
            char mark;
            cout<<"enter the fraction  : (nominator / denominator)"<<endl;
            in>>obj.num;
            in>>mark;
            if (mark!='/')
                cout<<"Error"<<endl;
            in>>obj.dnum;
            if (obj.dnum==0){
            cout<<" you have entered a 0 , denominator can not be 0"<<endl;}
      }while(obj.dnum==0);
}
/*_______________________________________________________________________________________________________________________________*/

/* output stream overloading function */
ostream  &operator<<(ostream &out,fraction &obj)
{
    //out<<"result is :"<<endl;
    out<<obj.num<<"/"<<obj.dnum;
    return out;
}

