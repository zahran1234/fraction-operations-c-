#ifndef FRACTIONCALCULATOR_H
#define FRACTIONCALCULATOR_H
#include "fraction.h"
#include <iostream>

class FractionCalculator:public fraction{
    public:
        FractionCalculator();
        void mnue();
        fraction anotheroperation(fraction & obj);
};

#endif // FRACTIONCALCULATOR_H
