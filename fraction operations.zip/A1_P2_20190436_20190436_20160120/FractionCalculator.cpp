#include "FractionCalculator.h"
#include "fraction.h"
#include <iostream>
using namespace std;
FractionCalculator::FractionCalculator()
{
    //ctor
}
/* this function is the actual main function has all the operations */
void FractionCalculator::mnue()
{
    char ans ='n';
    do{

    int choice , opr;
    cout<<"Welcome to FCI Fraction Calculator "<<endl;
    cout<<"____________________________________"<<endl;
    cout<<"1) Perform Fraction Addition "<<endl;
    cout<<"2) Perform Fraction Subtraction"<<endl;
    cout<<"3) Perform Fraction Multiplication"<<endl;
    cout<<"4) Perform Fraction Division"<<endl;
    cout<<"5) Perform Fraction Equality "<<endl;
    cout<<"6) Perform Fraction Greater Than"<<endl;
    cout<<"7) Perform Fraction Less Than"<<endl;
    cout<<"8) Perform Fraction Greater Than Or Equal"<<endl;
    cout<<"9) Perform Fraction Less Than Or Equal"<<endl;
    cout<<"10) EXIT"<<endl;
    cin>>opr;
    if(opr>10&&opr<1)
    cout<<"you have entered a wrong choice "<<endl;
        switch (opr){
    case 1:
        {fraction f1,f2,f3;
        cin>>f1;
        cin>>f2;
        f3=f1+f2;
        cout<<"the result is :"<<endl;
        cout<<f3<<endl;
        cout<<"would you like to have another operation? "<<endl;
        cin>>ans;
        if (ans=='y')
        f3=anotheroperation(f3);
        break;}
    case 2:

        {fraction f1,f2,f3;
        cin>>f1;
        cin>>f2;
        f3=f1-f2;
        cout<<"the result is :"<<endl;
        cout<<f3<<endl;
        cout<<"would you like to have another operation? "<<endl;
        cin>>ans;
        if (ans=='y')
        f3=anotheroperation(f3);
        break;}
    case 3:
       {

        fraction f1,f2,f3;
        cin>>f1;
        cin>>f2;
        f3=f1*f2;
        cout<<"the result is :"<<endl;
        cout<<f3;
        cout<<"would you like to have another operation? "<<endl;
        cin>>ans;
        if (ans=='y')
        f3=anotheroperation(f3);
        break;}
    case 4:
        {fraction f1,f2,f3;
        cin>>f1;
        cin>>f2;
        f3=f1/f2;
        cout<<"the result is :";
        cout<<f3;
        cout<<"would you like to have another operation? "<<endl;
        cin>>ans;
        if (ans=='y')
        f3=anotheroperation(f3);
        break;
        }
    case 5:
            {fraction f1,f2;
                cin>>f1;
                cin>>f2;
                if(f1==f2)
                {
                    cout<<"the two fractions are equale "<<endl;
                }
                else {cout<<"the two fractions are not equal"<<endl;}
                break;
            }
        case 6:
            {
                fraction f1,f2;
                cin>>f1;
                cin>>f2;
                if(f1>f2)
                {
                    cout<<"the fraction "<<f1<<" is greater than "<<f2<<endl;
                }
                break;
            }
        case 7:
            {
                fraction f1,f2;
                cin>>f1;
                cin>>f2;
                if(f1<f2)
                {
                    cout<<"the fraction "<<f1<<" is less than "<<f2<<endl;
                }
                break;
            }
        case 8:
            {
                fraction f1,f2;
                cin>>f1;
                cin>>f2;
                if(f1>=f2)
                {
                    cout<<"the fraction "<<f1<<" is greater than or equal to  "<<f2<<endl;
                }
                break;
            }
        case 9:
            {
                fraction f1,f2;
                cin>>f1;
                cin>>f2;
                if(f1>f2)
                {
                    cout<<"the fraction "<<f1<<" is less than or equal"<<f2<<endl;
                }
                break;
            }
        case 10:
            break;

        }
        cout<<"would you like to do another operation (y/n)"<<endl;
            cin>>ans;
    }while (ans=='y');
}
/*_______________________________________________________________________________________________________________________________*/

/* this function  for making another operation on the same fraction */


fraction FractionCalculator::anotheroperation(fraction & obj)
{
    int ch;
    cout<<"1) Perform Fraction Addition "<<endl;
    cout<<"2) Perform Fraction Subtraction"<<endl;
    cout<<"3) Perform Fraction Multiplication"<<endl;
    cout<<"4) Perform Fraction Division"<<endl;
    cin>>ch;
    switch (ch){
case 1:{
    fraction f1,f2;
    cin>>f1;
    f2=obj+f1;
    cout<<"result is :"<<endl;
    cout<<f2;
    break;
    }
case 2:
    {
    fraction f1,f2;
    cin>>f1;
    f2=obj-f1;
    cout<<"result is :"<<endl;
    cout<<f2;
    break;
    }
case 3:
    {
    fraction f1,f2;
    cin>>f1;
    f2=obj*f1;
    cout<<"result is :"<<endl;
    cout<<f2;
    break;
    }
case 4:
    {
    fraction f1,f2;
    cin>>f1;
    f2=obj/f1;
    cout<<"result is :"<<endl;
    cout<<f2;
    break;
    }
    }

}

